 <!-- Navbar & Hero Start -->

 
 <div class="container-xxl position-relative p-0  " >
            <nav class="navbar navbar-expand-lg navbar-light px-4 px-lg-5 py-3 py-lg-0">
                <a href="<?php echo e(url('/')); ?>" class="navbar-brand p-0">
                    <!-- <h1 class="m-0">Filatec</h1> -->
                    <img  class= "logo" src="theme/img/logo.png"  alt="Logo">
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                    <span class="fa fa-bars"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <div class="navbar-nav ms-auto py-0">
                        <a  href="<?php echo e(url('/')); ?>" class="nav-item nav-link ">Home</a>
                        <div class="nav-item dropdown">
                            <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">About</a>
                            <div class="dropdown-menu m-0">
                            <a href="<?php echo e(url('/about')); ?>" class="dropdown-item">About FILATEC</a>
                                <a href="<?php echo e(url('/careers')); ?>" class="dropdown-item">Careers</a>
                                <!-- <a href="<?php echo e(url('/team')); ?>" class="dropdown-item">Our Team</a> -->
                                <a href="<?php echo e(url('/contact')); ?>" class="dropdown-item">Contact us</a>
                                
                            </div>
                        </div>
                        <a  href="<?php echo e(url('/about')); ?>" class="nav-item nav-link ">What we do</a>
                         <a href="<?php echo e(url('/services')); ?>" class="nav-item nav-link">Where we focus</a>
                       
                        <a  href="<?php echo e(url('/project')); ?>" class="nav-item nav-link">Projects</a>
                    
                    </div>
                    <!-- <a href="<?php echo e(url('/quote')); ?>" class="btn btn-light rounded-pill text-primary py-2 px-4 ms-lg-5">Free Quote</a> -->
                </div>
            </nav>

        </div>
        <!-- Navbar & Hero End --><?php /**PATH C:\xampp\htdocs\projects\filatel\resources\views/header.blade.php ENDPATH**/ ?>