<!-- Footer Start -->
<div class="container-fluid bg-dark text-light footer pt-5 wow fadeIn" data-wow-delay="0.1s" style="margin-top: 6rem;">
            <div class="container py-5">
                <div class="row g-5">
                
                    <div class="col-md-6 col-lg-4">
                     
                        <p><i class="fa fa-map-marker-alt me-3"></i>Landmark Plaza, Upperhill, Nairobi, Kenya</p>
                        <p><i class="fa fa-phone-alt me-3"></i>+254 202033395/ +254 0735697259</p>
                        <p><i class="fa fa-envelope me-3"></i>info@filatec.co.ke</p>
                       
                    </div>
                    <div class="col-md-6 col-lg-4">
                      
                        <a class="btn btn-link" href="">About Us</a>
                  
                      
                        <a class="btn btn-link" href="">Career</a>
                    </div>

                    <div class="col-md-6 col-lg-4">
             
                    <div class="d-flex pt-2">
                            <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-twitter"></i></a>
                            <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-facebook-f"></i></a>
                           
                            <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-instagram"></i></a>
                            <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-linkedin-in"></i></a>
                        </div>
                    </div>
                   
                </div>
            </div>
            <div class="container">
                <div class="copyright">
                    <div class="row">
                        <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                            &copy; <a class="border-bottom" href="#">Filatec</a>, All Right Reserved. 
							
							
                        </div>
                      
                    </div>
                </div>
            </div>
        </div><?php /**PATH C:\xampp\htdocs\projects\filatel\resources\views/footer.blade.php ENDPATH**/ ?>